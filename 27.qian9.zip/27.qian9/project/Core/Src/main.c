/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "gpdma.h"
#include "i2c.h"
#include "icache.h"
#include "memorymap.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "max30102.h"
//#include "oled.h"
#include "ws2812.h"
#include "string.h"
#include "stdio.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
uint8_t rx_pointer=0,rx_data;
uint8_t rx_buff[30];
uint8_t tx_buff[300];
uint8_t count=0;
uint8_t key_flag=0;
uint8_t key_count=0;
int32_t HR_Value,BO_Value;
uint8_t led_flag=0;
char send_data[100];
uint8_t stream=0;
uint8_t stime=0;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
//unsigned char hanzi1[2][16]={
//{0x00,0x00,0xF8,0x08,0x08,0xF8,0x0C,0x0B,0x08,0xF8,0x08,0x08,0xF8,0x00,0x00,0x00},
//{0x40,0x40,0x7F,0x40,0x40,0x7F,0x40,0x40,0x40,0x7F,0x40,0x40,0x7F,0x40,0x40,0x00},/*"Ѫ",0*/
//};

//unsigned char hanzi2[2][16]={
//{0x08,0x24,0x23,0x6A,0xAA,0x2A,0xAA,0x6A,0x2A,0x2A,0x2A,0xEA,0x02,0x02,0x00,0x00},
//{0x10,0x11,0x15,0x15,0x15,0xFF,0x15,0x15,0x15,0x11,0x10,0x0F,0x30,0x40,0xF8,0x00},/*"氧",1*/
//};

//unsigned char hanzi3[2][16]={
//{0x00,0x00,0x80,0x00,0x00,0xE0,0x02,0x04,0x18,0x00,0x00,0x00,0x40,0x80,0x00,0x00},
//{0x10,0x0C,0x03,0x00,0x00,0x3F,0x40,0x40,0x40,0x40,0x40,0x78,0x00,0x01,0x0E,0x00},/*"心",0*/
//};

//unsigned char hanzi4[2][16]={
//{0x00,0x14,0xA4,0x44,0x24,0x34,0xAD,0x66,0x24,0x94,0x04,0x44,0xA4,0x14,0x00,0x00},
//{0x08,0x09,0x08,0x08,0x09,0x09,0x09,0xFD,0x09,0x09,0x0B,0x08,0x08,0x09,0x08,0x00},/*"率",0*/
//};

//BMP bmp1={
//.xSize=16,
//.ySize=16,
//.p=hanzi1
//};
//BMP bmp2={
//.xSize=16,
//.ySize=16,
//.p=hanzi2
//};
//BMP bmp3={
//.xSize=16,
//.ySize=16,
//.p=hanzi3
//};
//BMP bmp4={
//.xSize=16,
//.ySize=16,
//.p=hanzi4
//};
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void Read(void)
{
	int8_t HR_Valid,BO_Valid;
	Max30102_Calculate_HR_BO_Value(&HR_Value,&HR_Valid,&BO_Value,&BO_Valid);
	if(HR_Valid==1 && BO_Valid==1)
	{
//		OLED_ShowString(1,1,(uint8_t*)"HR:",sizeof("HR:"));
//		OLED_ShowString(2,2,(uint8_t*)"BO:",sizeof("BO:"));
//		sprintf(send_data,"%d %%    %d %%   ",BO_Value,HR_Value);
//		OLED_ShowString(5,40,(uint8_t*)send_data,sizeof(send_data));
//		OLED_ShowNum(70,3,HR_Value,sizeof(HR_Value));
//		OLED_ShowNum(0,3,BO_Value,sizeof(BO_Value));
		
		sprintf(send_data,"心率:%d    血氧:%d   ",HR_Value,BO_Value);
		HAL_UART_Transmit(&huart2,(uint8_t*)send_data,sizeof(send_data),500);
		HAL_UART_Transmit(&huart2,(uint8_t*)"AT+CIPSEND=0,30\r\n",sizeof("AT+CIPSEND=0,30\r\n"),50);
	}
}


	void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if(huart->Instance==USART2)
{
HAL_UART_Receive_IT(&huart2,&rx_data,1);
rx_buff[rx_pointer++]=rx_data;
}
}
	
	void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
if(htim->Instance==TIM1)
{
if(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_6)==GPIO_PIN_RESET&&key_flag==0)
{
	stream=0;
led_flag=0;
key_count++;
key_count%=2;
key_flag=1;
}

else if(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_6)==GPIO_PIN_SET)
{
key_flag=0;
}

if(key_count==0)
{
HAL_GPIO_WritePin(GPIOD,GPIO_PIN_9,GPIO_PIN_RESET);
HAL_GPIO_WritePin(GPIOD,GPIO_PIN_10,GPIO_PIN_SET);	
	if(HR_Value<110)
	{
		if(led_flag!=1)
		{
	for(int i=0;i<=12;i++)
		{
		Set_LED(i,0,0,500);
		}
		WS2812_Send ();
		led_flag=1;
	}
}
else if(HR_Value>=110&&HR_Value<160)
{
	if(led_flag!=2)
	{
for(int j=0;j<=12;j++)
		{
		Set_LED(j,0,500,0);
		}
		WS2812_Send ();
		led_flag=2;
}
	}
else if(HR_Value>=180)
{
	Set_LED(0,500,0,0);
	if(led_flag!=3)
	{
for(int j=1;j<=12;j++)
		{
		Set_LED(j,500,0,0);
		}
		WS2812_Send ();
		led_flag=3;
}
	}
}

else if(key_count==1)
{
HAL_GPIO_WritePin(GPIOD,GPIO_PIN_9,GPIO_PIN_SET);
HAL_GPIO_WritePin(GPIOD,GPIO_PIN_10,GPIO_PIN_RESET);
}
}

if(htim->Instance==TIM2)
{
	
	if(key_count==1)
	{
	if(rx_pointer==14&&rx_buff[13]==0x32)
{
		stream=0;
    for(int i=0;i<=12;i++)
    {
    Set_LED(i,500,0,0);
    }
WS2812_Send ();
}

else if(rx_pointer==14&&rx_buff[13]==0x34)
{
		stream=0;
    for(int i=0;i<=12;i++)
    {
    Set_LED(i,0,500,0);
    }
    WS2812_Send ();
}

else if(rx_pointer==14&&rx_buff[13]==0x31&&rx_buff[12]==0x35)
{
		stream=0;
    for(int i=0;i<=12;i++)
    {
    Set_LED(i,0,0,0);
    }
    WS2812_Send();
}

else if(rx_pointer==14&&rx_buff[13]==0x35)
{
		stream=0;
    for(int i=0;i<=12;i++)
    {
    Set_LED(i,0,0,500);
    }
    WS2812_Send();
}

else if(rx_pointer==14&&rx_buff[13]==0x31&&rx_buff[12]==0x37)
{
led_flag=0;
stream=1;
}

if(stream==1)
{
stime++;
if(stime>=0&&stime<=3)
{
Set_LED(12,0,0,0);
Set_LED(0,500,0,0);
Set_LED(1,0,500,0);
WS2812_Send();
}
else if(stime>3&&stime<=6)
{
Set_LED(0,0,0,0);
Set_LED(1,0,0,0);
Set_LED(2,0,0,500);
Set_LED(3,400,100,0);
	WS2812_Send();
}
else if(stime>6&&stime<=9)
{
Set_LED(0,0,0,0);
Set_LED(2,0,0,0);
Set_LED(3,0,0,0);
Set_LED(4,300,100,100);
Set_LED(5,200,200,100);
	WS2812_Send();
}
else if(stime>9&&stime<=12)
{
Set_LED(0,0,0,0);
Set_LED(4,0,0,0);
Set_LED(5,0,0,0);
Set_LED(6,100,200,200);
Set_LED(7,0,100,400);
	WS2812_Send();
}
else if(stime>12&&stime<=15)
{
Set_LED(0,0,0,0);
Set_LED(6,0,0,0);
Set_LED(7,0,0,0);
Set_LED(8,100,100,300);
Set_LED(9,100,0,400);
	WS2812_Send();
}
else if(stime>15&&stime<=18)
{
Set_LED(0,0,0,0);
Set_LED(8,0,0,0);
Set_LED(9,0,0,0);
Set_LED(10,0,400,100);
Set_LED(11,100,300,100);
	WS2812_Send();
}
else if(stime>18&&stime<=21)
{
Set_LED(0,0,0,0);
Set_LED(10,0,0,0);
Set_LED(11,0,0,0);
Set_LED(12,50,400,50);
WS2812_Send();
}
else if(stime>21)
{
stime=0;
}
}
}

if(rx_pointer==14&&rx_buff[13]==0x30)
{
led_flag=0;
key_count++;
key_count%=2;
}

rx_pointer=0;
memset(rx_buff,0,sizeof(rx_buff));
}
	}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
uint8_t send_data2[]="AT+CWMODE=2\r\n";
uint8_t send_data3[]="AT+CWSAP=""ESP8266_AP"",""12345678"",1,4\r\n";
uint8_t send_data4[]="AT+CIPMUX=1\r\n";
uint8_t send_data5[]="AT+CIPSERVER=1,8088\r\n";
uint8_t send_data6[]="AT+CIPSEND\r\n";
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_GPDMA1_Init();
  MX_I2C2_Init();
  MX_TIM4_Init();
  MX_USART2_UART_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_ICACHE_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
//OLED_Init();
//OLED_Clear();
Max30102_Init();
HAL_TIM_Base_Start_IT(&htim1);
HAL_TIM_Base_Start_IT(&htim2);
//OLED_ShowPic(0,0,bmp1);
//OLED_ShowPic(20,0,bmp2);
//OLED_ShowPic(70,0,bmp3);
//OLED_ShowPic(90,0,bmp4);
//OLED_ShowString(32,3,(uint8_t*)"%",sizeof("%"));
//OLED_ShowString(100,3,(uint8_t*)"bpm",sizeof("bpm"));
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
// 	OLED_ShowString(4,7,(uint8_t*)"hello world!",sizeof("hello world!"));
  Max30102_Safety();
HAL_UART_Receive_IT(&huart2,&rx_data,1);
HAL_UART_Transmit(&huart2,send_data2,sizeof(send_data2),50);
HAL_Delay(100);
HAL_UART_Transmit(&huart2,send_data3,sizeof(send_data3),50);
HAL_Delay(1000);
HAL_UART_Transmit(&huart2,send_data4,sizeof(send_data4),50);
HAL_Delay(100);
HAL_UART_Transmit(&huart2,send_data5,sizeof(send_data5),50);
HAL_Delay(10);
HAL_UART_Transmit(&huart2,send_data6,sizeof(send_data6),50);
  while (1)
  {
		Read();
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMBOOST = RCC_PLLMBOOST_DIV1;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = 2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 1;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLLVCIRANGE_1;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_PCLK3;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
